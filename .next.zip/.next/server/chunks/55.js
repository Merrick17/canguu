"use strict";
exports.id = 55;
exports.ids = [55];
exports.modules = {

/***/ 55:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V7": () => (/* binding */ storeContractAddress),
/* harmony export */   "tx": () => (/* binding */ nftContractAddress)
/* harmony export */ });
/* harmony import */ var _nft_abi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7569);
const nftContractAddress = "0xBa742D81Cc760db863C353EC48E02F9F5480F9DE";
const storeContractAddress = "0xAf4a7b3459C529E510D452d8F1C1C275F6f4A404";




/***/ }),

/***/ 7569:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ NFT_ABI),
/* harmony export */   "o": () => (/* binding */ STORE_ABI)
/* harmony export */ });
const NFT_ABI = [
    {
        inputs: [],
        stateMutability: "nonpayable",
        type: "constructor"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: "address",
                name: "owner",
                type: "address"
            },
            {
                indexed: true,
                internalType: "address",
                name: "approved",
                type: "address"
            },
            {
                indexed: true,
                internalType: "uint256",
                name: "tokenId",
                type: "uint256"
            }, 
        ],
        name: "Approval",
        type: "event"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: "address",
                name: "owner",
                type: "address"
            },
            {
                indexed: true,
                internalType: "address",
                name: "operator",
                type: "address"
            },
            {
                indexed: false,
                internalType: "bool",
                name: "approved",
                type: "bool"
            }, 
        ],
        name: "ApprovalForAll",
        type: "event"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "to",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "tokenId",
                type: "uint256"
            }, 
        ],
        name: "approve",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "string",
                name: "_tokenURI",
                type: "string"
            }, 
        ],
        name: "mint",
        outputs: [
            {
                internalType: "uint256",
                name: "",
                type: "uint256"
            }, 
        ],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "from",
                type: "address"
            },
            {
                internalType: "address",
                name: "to",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "tokenId",
                type: "uint256"
            }, 
        ],
        name: "safeTransferFrom",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "from",
                type: "address"
            },
            {
                internalType: "address",
                name: "to",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "tokenId",
                type: "uint256"
            },
            {
                internalType: "bytes",
                name: "data",
                type: "bytes"
            }, 
        ],
        name: "safeTransferFrom",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "operator",
                type: "address"
            },
            {
                internalType: "bool",
                name: "approved",
                type: "bool"
            }, 
        ],
        name: "setApprovalForAll",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: "address",
                name: "from",
                type: "address"
            },
            {
                indexed: true,
                internalType: "address",
                name: "to",
                type: "address"
            },
            {
                indexed: true,
                internalType: "uint256",
                name: "tokenId",
                type: "uint256"
            }, 
        ],
        name: "Transfer",
        type: "event"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "from",
                type: "address"
            },
            {
                internalType: "address",
                name: "to",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "tokenId",
                type: "uint256"
            }, 
        ],
        name: "transferFrom",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "owner",
                type: "address"
            }, 
        ],
        name: "balanceOf",
        outputs: [
            {
                internalType: "uint256",
                name: "",
                type: "uint256"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "uint256",
                name: "tokenId",
                type: "uint256"
            }, 
        ],
        name: "getApproved",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "owner",
                type: "address"
            },
            {
                internalType: "address",
                name: "operator",
                type: "address"
            }, 
        ],
        name: "isApprovedForAll",
        outputs: [
            {
                internalType: "bool",
                name: "",
                type: "bool"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [],
        name: "name",
        outputs: [
            {
                internalType: "string",
                name: "",
                type: "string"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "uint256",
                name: "tokenId",
                type: "uint256"
            }, 
        ],
        name: "ownerOf",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "bytes4",
                name: "interfaceId",
                type: "bytes4"
            }, 
        ],
        name: "supportsInterface",
        outputs: [
            {
                internalType: "bool",
                name: "",
                type: "bool"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [],
        name: "symbol",
        outputs: [
            {
                internalType: "string",
                name: "",
                type: "string"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [],
        name: "tokenCount",
        outputs: [
            {
                internalType: "uint256",
                name: "",
                type: "uint256"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "uint256",
                name: "tokenId",
                type: "uint256"
            }, 
        ],
        name: "tokenURI",
        outputs: [
            {
                internalType: "string",
                name: "",
                type: "string"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    }, 
];
const STORE_ABI = [
    {
        inputs: [
            {
                internalType: "uint256",
                name: "_benPercent",
                type: "uint256"
            }, 
        ],
        stateMutability: "nonpayable",
        type: "constructor"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: false,
                internalType: "uint256",
                name: "itemId",
                type: "uint256"
            },
            {
                indexed: true,
                internalType: "address",
                name: "nft",
                type: "address"
            },
            {
                indexed: false,
                internalType: "uint256",
                name: "tokenId",
                type: "uint256"
            },
            {
                indexed: false,
                internalType: "uint256",
                name: "price",
                type: "uint256"
            },
            {
                indexed: true,
                internalType: "address",
                name: "seller",
                type: "address"
            },
            {
                indexed: true,
                internalType: "address",
                name: "buyer",
                type: "address"
            }, 
        ],
        name: "Bought",
        type: "event"
    },
    {
        inputs: [
            {
                internalType: "uint256",
                name: "_itemId",
                type: "uint256"
            }, 
        ],
        name: "buyItem",
        outputs: [],
        stateMutability: "payable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "contract IERC721",
                name: "_nft",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "_tokenId",
                type: "uint256"
            },
            {
                internalType: "uint256",
                name: "_price",
                type: "uint256"
            }, 
        ],
        name: "makeItem",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: false,
                internalType: "uint256",
                name: "itemId",
                type: "uint256"
            },
            {
                indexed: true,
                internalType: "address",
                name: "nft",
                type: "address"
            },
            {
                indexed: false,
                internalType: "uint256",
                name: "tokenId",
                type: "uint256"
            },
            {
                indexed: false,
                internalType: "uint256",
                name: "price",
                type: "uint256"
            },
            {
                indexed: true,
                internalType: "address",
                name: "seller",
                type: "address"
            }, 
        ],
        name: "nftOn",
        type: "event"
    },
    {
        inputs: [],
        name: "benAccount",
        outputs: [
            {
                internalType: "address payable",
                name: "",
                type: "address"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [],
        name: "benPercent",
        outputs: [
            {
                internalType: "uint256",
                name: "",
                type: "uint256"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "uint256",
                name: "_itemId",
                type: "uint256"
            }, 
        ],
        name: "getTotalPrice",
        outputs: [
            {
                internalType: "uint256",
                name: "",
                type: "uint256"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [],
        name: "itemCount",
        outputs: [
            {
                internalType: "uint256",
                name: "",
                type: "uint256"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "uint256",
                name: "",
                type: "uint256"
            }, 
        ],
        name: "items",
        outputs: [
            {
                internalType: "uint256",
                name: "itemId",
                type: "uint256"
            },
            {
                internalType: "contract IERC721",
                name: "nft",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "tokenId",
                type: "uint256"
            },
            {
                internalType: "uint256",
                name: "price",
                type: "uint256"
            },
            {
                internalType: "address payable",
                name: "seller",
                type: "address"
            },
            {
                internalType: "bool",
                name: "sold",
                type: "bool"
            }, 
        ],
        stateMutability: "view",
        type: "function"
    }, 
];



/***/ })

};
;