"use strict";
(() => {
var exports = {};
exports.id = 748;
exports.ids = [748];
exports.modules = {

/***/ 7167:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ auth)
});

;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
;// CONCATENATED MODULE: external "next-auth/providers/credentials"
const credentials_namespaceObject = require("next-auth/providers/credentials");
var credentials_default = /*#__PURE__*/__webpack_require__.n(credentials_namespaceObject);
;// CONCATENATED MODULE: external "next-auth/react"
const react_namespaceObject = require("next-auth/react");
;// CONCATENATED MODULE: external "siwe"
const external_siwe_namespaceObject = require("siwe");
;// CONCATENATED MODULE: ./src/pages/api/auth/[...nextauth].ts




async function auth(req, res) {
    const providers = [
        credentials_default()({
            name: "Ethereum",
            credentials: {
                message: {
                    label: "Message",
                    type: "text",
                    placeholder: "0x0"
                },
                signature: {
                    label: "Signature",
                    type: "text",
                    placeholder: "0x0"
                }
            },
            async authorize (credentials) {
                try {
                    console.log("credentials?.message", credentials?.message);
                    const siwe = new external_siwe_namespaceObject.SiweMessage(JSON.parse(credentials?.message || "{}"));
                    const nextAuthUrl = process.env.NEXTAUTH_URL || (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : null);
                    if (!nextAuthUrl) {
                        return null;
                    }
                    const nextAuthHost = new URL(nextAuthUrl).host;
                    if (siwe.domain !== nextAuthHost) {
                        return null;
                    }
                    if (siwe.nonce !== await (0,react_namespaceObject.getCsrfToken)({
                        req
                    })) {
                        return null;
                    }
                    await siwe.validate(credentials?.signature || "");
                    return {
                        id: siwe.address
                    };
                } catch (e) {
                    return null;
                }
            }
        }), 
    ];
    // @ts-ignore
    const isDefaultSigninPage = req.method === "GET" && req.query.nextauth && req.query.nextauth.includes("signin");
    // Hide Sign-In with Ethereum from default sign page
    if (isDefaultSigninPage) {
        providers.pop();
    }
    return await external_next_auth_default()(req, res, {
        // https://next-auth.js.org/configuration/providers/oauth
        providers,
        session: {
            strategy: "jwt"
        },
        secret: process.env.NEXTAUTH_SECRET,
        callbacks: {
            async session ({ session , token  }) {
                // @ts-ignore
                session.address = token.sub;
                // @ts-ignore
                session.user.name = token.sub;
                return session;
            }
        }
    });
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7167));
module.exports = __webpack_exports__;

})();